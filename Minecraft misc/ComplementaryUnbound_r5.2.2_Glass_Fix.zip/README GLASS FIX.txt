This fixes both glass casting shadows, and glass not actually connecting when the setting is turned on. 
It's more of a workaround than a proper fix though, I'm not knowledgeable enough to do that unfortunately...

There is no intent to pretend the shader pack is my own, it's an otherwise unchanged copy of Complementary Unbound.