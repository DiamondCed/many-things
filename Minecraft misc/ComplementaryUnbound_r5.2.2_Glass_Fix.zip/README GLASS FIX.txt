This fix doesn't actually restore the intended functionality, rather finding a "more favorable" broken state for the average player.

There is no intent to pretend the shader pack is my own, it's an otherwise unchanged copy of Complementary Unbound.